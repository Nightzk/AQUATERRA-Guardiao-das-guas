
DROP TABLE player_quests;
DROP TABLE quests;
DROP TABLE enemies;
DROP TABLE areas;
DROP TABLE players;
